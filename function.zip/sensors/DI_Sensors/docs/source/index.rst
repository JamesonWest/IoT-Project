.. DI-Sensors documentation master file, created by
   sphinx-quickstart on Thu Sep 28 21:00:03 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

###########################################
Dexter Industries DI-Sensors Documentation!
###########################################

.. image:: images/dexterlogo_small.jpg

.. toctree::
   :maxdepth: 2
   :numbered:
   :caption: Contents:

   about
   quickstart
   examples/index
   structure
   api-basic
   api-advanced
   devguide
   faq

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
