.. _faq-chapter:

##########################
Frequently Asked Questions
##########################

For more questions, please head over to our Dexter Industries `forum`_.


.. _forum: http://forum.dexterindustries.com/categories
