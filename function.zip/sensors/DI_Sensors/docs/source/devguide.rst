.. _devguide-chapter:

#################
Developer's Guide
#################

*****************
Our collaborators
*****************

The following collaborators are ordered alphabetically:

* John Cole - `Github Account <https://github.com/johnisanerd/>`__.
* Karan Nayan - `Github Account <https://github.com/karan259>`__.
* Matt Richardson - `Github Account <https://github.com/mattallen37/>`__.
* Nicole Parrot - `Github Account <https://github.com/cleoqc/>`__.
* Robert Lucian Chiriac - `Github Account <https://github.com/RobertLucian/>`__.
* Shoban Narayan - `Github account <https://github.com/shoban94>`__.
