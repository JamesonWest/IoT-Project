#! /bin/bash
 #OBSOLETE


screen -d -r local
# sudo python /home/pi/Desktop/GoBox/Scratch_GUI/Scratch_Start.py
python /home/pi/Dexter/lib/Dexter/Scratch_GUI/Scratch_Start.py

##
# Below is the graveyard of calls unsuccessfully tried to make this work.  
# sudo lxterminal --command "sudo xhost +"
#sudo lxterminal --command "sudo python /home/pi/Desktop/DexterEd/Scratch_GUI/Scratch_Start.py"
#lxterminal --command "sudo python /home/pi/Desktop/DexterEd/Scratch_GUI/Scratch_Start.py"